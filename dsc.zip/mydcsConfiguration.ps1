Configuration Main
{
	Param ( [string] $nodeName )

	Import-DscResource -ModuleName PSDesiredStateConfiguration
	Import-DSCResource -Module xSystemSecurity -Name xIEEsc -ModuleVersion "1.1.0.0"

	Node $nodeName
	{

		xIEEsc DisableIEEscAdmin
		{
			IsEnabled = $false
			UserRole  = "Administrators"
		}

		xIEEsc DisableIEEsc
		{
			IsEnabled = $false
			UserRole = "Users"
		}

		Registry EnableDownloads
		{
			Ensure = "Present"
			Key = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\Zones\3"
			ValueName = "1803"
			ValueData = "0"
			ValueType = "Dword"
		}

		Registry DisablePopUp
		{
			Ensure = "Present"
			Key = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\Zones\3"
			ValueName = "1809"
			ValueData = "0"
			ValueType = "Dword"
		}
	}
}